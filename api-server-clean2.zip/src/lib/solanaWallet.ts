import * as web3 from "@solana/web3.js";
import * as bip39 from "bip39";
import { derivePath } from "ed25519-hd-key";

const FOGO_RPC = "https://mainnet.fogo.io";
const FOGO_EXPLORER = "https://explorer.fogo.io";
const FOGO_LAMPORTS = 1e9;

const EXCHANGE_DEPOSIT_ADDRESSES: Record<string, string> = {
  VALIANT:  "GSxJyS7dNHFFLM2kbdGN9AkzvcDuNofDXzUHU2jyVkd3",
  BINANCE:  "CBrzzLW6oFu9Vh247yVjtREGwVUmHV7DwwMfaLZn6GsK",
  MEXC:     "6qb1KHPn5W9JG26cWMTgTjipN1LusTYqD8N5vRNRsAzV",
  KUCOIN:   "2AWnybpXLSySCQAk4ccu6Tcive2rQnxBdGLQN7aLPWMR",
};

let _keypair: web3.Keypair | null = null;
let _fogoConn: web3.Connection | null = null;

export function getKeypair(): web3.Keypair {
  if (_keypair) return _keypair;
  const phrase = process.env.PHANTOM_SEED_PHRASE;
  if (!phrase) throw new Error("PHANTOM_SEED_PHRASE not configured");
  const seed = bip39.mnemonicToSeedSync(phrase.trim(), "");
  const { key } = derivePath("m/44'/501'/0'/0'", seed.toString("hex"));
  _keypair = web3.Keypair.fromSeed(key);
  return _keypair;
}

export function getWalletAddress(): string {
  return getKeypair().publicKey.toBase58();
}

export function getFogoConnection(): web3.Connection {
  if (_fogoConn) return _fogoConn;
  _fogoConn = new web3.Connection(FOGO_RPC, {
    commitment: "confirmed",
    confirmTransactionInitialTimeout: 10000,
  });
  return _fogoConn;
}

export function getExchangeAddress(exchange: string): string {
  const key = exchange.toUpperCase().replace(/ /g, "").replace("DEX", "");
  return EXCHANGE_DEPOSIT_ADDRESSES[key] || "";
}

export async function getFogoBalance(address?: string): Promise<number> {
  const conn = getFogoConnection();
  const pubkey = address
    ? new web3.PublicKey(address)
    : getKeypair().publicKey;
  const lamports = await conn.getBalance(pubkey);
  return lamports / FOGO_LAMPORTS;
}

export interface TokenAccount {
  mint: string;
  symbol: string;
  uiAmount: number;
  decimals: number;
  ata: string;
}

export async function getFogoTokenAccounts(): Promise<TokenAccount[]> {
  const conn = getFogoConnection();
  const kp = getKeypair();
  try {
    const accounts = await conn.getParsedTokenAccountsByOwner(kp.publicKey, {
      programId: new web3.PublicKey("TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"),
    });
    return accounts.value
      .map((a) => {
        const info = a.account.data.parsed.info;
        return {
          mint: info.mint,
          symbol: info.mint.slice(0, 8) + "…",
          uiAmount: info.tokenAmount.uiAmount ?? 0,
          decimals: info.tokenAmount.decimals,
          ata: a.pubkey.toBase58(),
        };
      })
      .filter((t) => t.uiAmount > 0);
  } catch {
    return [];
  }
}

export interface TransferResult {
  signature: string;
  status: "confirmed" | "failed";
  explorerUrl: string;
  latencyMs: number;
  error?: string;
}

export async function transferFogo(
  toAddress: string,
  fogoAmount: number
): Promise<TransferResult> {
  const start = Date.now();
  const conn = getFogoConnection();
  const kp = getKeypair();
  const toPubkey = new web3.PublicKey(toAddress);
  const lamports = Math.floor(fogoAmount * FOGO_LAMPORTS);

  const { blockhash, lastValidBlockHeight } = await conn.getLatestBlockhash("confirmed");
  const tx = new web3.Transaction({ recentBlockhash: blockhash, feePayer: kp.publicKey });
  tx.add(web3.SystemProgram.transfer({ fromPubkey: kp.publicKey, toPubkey, lamports }));
  tx.sign(kp);

  const rawTx = tx.serialize();
  const signature = await conn.sendRawTransaction(rawTx, {
    skipPreflight: false,
    preflightCommitment: "confirmed",
  });

  const result = await conn.confirmTransaction(
    { signature, blockhash, lastValidBlockHeight },
    "confirmed"
  );
  const latencyMs = Date.now() - start;

  if (result.value.err) {
    return {
      signature,
      status: "failed",
      explorerUrl: `${FOGO_EXPLORER}/tx/${signature}`,
      latencyMs,
      error: JSON.stringify(result.value.err),
    };
  }
  return {
    signature,
    status: "confirmed",
    explorerUrl: `${FOGO_EXPLORER}/tx/${signature}`,
    latencyMs,
  };
}

export async function transferFogoToExchange(
  exchange: string,
  fogoAmount: number
): Promise<TransferResult> {
  const addr = getExchangeAddress(exchange);
  if (!addr) throw new Error(`No deposit address for exchange: ${exchange}`);
  return transferFogo(addr, fogoAmount);
}

export function walletReady(): boolean {
  try {
    const phrase = process.env.PHANTOM_SEED_PHRASE;
    return !!phrase && phrase.trim().split(" ").length >= 12;
  } catch { return false; }
}

export { EXCHANGE_DEPOSIT_ADDRESSES, FOGO_RPC, FOGO_EXPLORER };
