import { Router, type IRouter } from "express";
import crypto from "crypto";

const router: IRouter = Router();

const BINANCE_BASES = [
  "https://api1.binance.com",
  "https://api2.binance.com",
  "https://api3.binance.com",
  "https://api.binance.com",
];
const API_KEY = process.env.BINANCE_API_KEY || "";
const SECRET_KEY = process.env.BINANCE_SECRET_KEY || "";

function sign(queryString: string): string {
  return crypto.createHmac("sha256", SECRET_KEY).update(queryString).digest("hex");
}

function buildHeaders() {
  return { "X-MBX-APIKEY": API_KEY, "Content-Type": "application/json" };
}

async function binanceFetch(method: string, path: string, params: Record<string, string> = {}, signed = false): Promise<any> {
  const qs = new URLSearchParams(params);
  if (signed) {
    qs.set("timestamp", String(Date.now()));
    qs.set("signature", sign(qs.toString()));
  }
  const query = qs.toString();
  const suffix = query ? `?${query}` : "";

  for (const base of BINANCE_BASES) {
    try {
      const url = `${base}${path}${suffix}`;
      const r = await fetch(url, {
        method,
        headers: buildHeaders(),
        signal: AbortSignal.timeout(6000),
      });
      if (r.status === 451) continue;
      if (!r.ok) {
        const body = await r.text();
        throw new Error(`Binance ${r.status}: ${body}`);
      }
      return r.json();
    } catch (err: any) {
      if (err?.message?.includes("451")) continue;
      if (err?.name === "TimeoutError") continue;
      throw err;
    }
  }
  throw new Error("Binance: all API endpoints unavailable (geo-blocked). Use mobile app for trading.");
}

router.get("/status", async (_req, res) => {
  const connected = !!API_KEY && !!SECRET_KEY;
  let reachable = false;
  try {
    await binanceFetch("GET", "/api/v3/ping");
    reachable = true;
  } catch { /* geo-blocked */ }
  res.json({ connected, reachable, exchange: "Binance", note: reachable ? "API accessible" : "API geo-blocked from server, use mobile app" });
});

router.get("/account", async (_req, res) => {
  try {
    const data = await binanceFetch("GET", "/api/v3/account", {}, true);
    res.json(data);
  } catch (err: any) {
    console.error("Binance account error:", err.message);
    res.status(500).json({ error: err.message });
  }
});

router.get("/ticker", async (req, res) => {
  try {
    const { symbol } = req.query as { symbol?: string };
    const params: Record<string, string> = {};
    if (symbol) params.symbol = symbol;
    const data = await binanceFetch("GET", "/api/v3/ticker/24hr", params);
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.get("/depth", async (req, res) => {
  try {
    const { symbol = "BTCUSDT", limit = "20" } = req.query as any;
    const data = await binanceFetch("GET", "/api/v3/depth", { symbol, limit });
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.get("/klines", async (req, res) => {
  try {
    const { symbol = "BTCUSDT", interval = "15m", limit = "100" } = req.query as any;
    const data = await binanceFetch("GET", "/api/v3/klines", { symbol, interval, limit });
    const candles = (data as any[]).map((k: any) => ({
      t: k[0], o: parseFloat(k[1]), h: parseFloat(k[2]),
      l: parseFloat(k[3]), c: parseFloat(k[4]), v: parseFloat(k[5]),
    }));
    res.json(candles);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.get("/trades", async (req, res) => {
  try {
    const { symbol = "BTCUSDT", limit = "50" } = req.query as any;
    const data = await binanceFetch("GET", "/api/v3/trades", { symbol, limit });
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.get("/open-orders", async (req, res) => {
  try {
    const { symbol } = req.query as { symbol?: string };
    const params: Record<string, string> = {};
    if (symbol) params.symbol = symbol;
    const data = await binanceFetch("GET", "/api/v3/openOrders", params, true);
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.get("/my-trades", async (req, res) => {
  try {
    const { symbol = "BTCUSDT", limit = "20" } = req.query as any;
    const data = await binanceFetch("GET", "/api/v3/myTrades", { symbol, limit }, true);
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post("/order", async (req, res): Promise<void> => {
  try {
    const { symbol, side, type, quantity, price, quoteOrderQty } = req.body || {};
    if (!symbol || !side || !type) {
      res.status(400).json({ error: "symbol, side, type required" });
      return;
    }
    const params: Record<string, string> = { symbol, side, type };
    if (quantity) params.quantity = String(quantity);
    if (price) params.price = String(price);
    if (quoteOrderQty) params.quoteOrderQty = String(quoteOrderQty);
    const data = await binanceFetch("POST", "/api/v3/order", params, true);
    res.json(data);
  } catch (err: any) {
    console.error("Binance order error:", err.message);
    res.status(500).json({ error: err.message });
  }
});

router.delete("/order", async (req, res): Promise<void> => {
  try {
    const { symbol, orderId } = req.query as any;
    if (!symbol || !orderId) {
      res.status(400).json({ error: "symbol, orderId required" });
      return;
    }
    const data = await binanceFetch("DELETE", "/api/v3/order", { symbol, orderId }, true);
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
