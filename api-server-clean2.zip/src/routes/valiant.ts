import { Router, type IRouter, type Request, type Response, type NextFunction } from "express";
import {
  getWalletAddress,
  getFogoBalance,
  getFogoTokenAccounts,
  transferFogo,
  transferFogoToExchange,
  walletReady,
  getFogoConnection,
  getKeypair,
  getExchangeAddress,
  type TokenAccount,
  EXCHANGE_DEPOSIT_ADDRESSES,
  FOGO_RPC,
  FOGO_EXPLORER,
} from "../lib/solanaWallet.js";

const router: IRouter = Router();

const SESSION_SECRET = process.env.SESSION_SECRET || "";
function requireAuth(req: Request, res: Response, next: NextFunction): void {
  const authHeader = req.headers.authorization || req.headers["x-api-key"] || "";
  const token = typeof authHeader === "string" ? authHeader.replace("Bearer ", "") : "";
  if (!SESSION_SECRET || token !== SESSION_SECRET) {
    res.status(403).json({ error: "Unauthorized — valid API key required for fund operations" });
    return;
  }
  next();
}

function validateAmount(val: unknown): number | null {
  const n = Number(val);
  if (!Number.isFinite(n) || n <= 0 || n > 1_000_000) return null;
  return n;
}

const VALID_EXCHANGES = ["MEXC", "BINANCE", "KUCOIN", "VALIANT"];

const MEXC_BASE = "https://api.mexc.com";

async function mexcOrder(params: {
  symbol: string;
  side: "BUY" | "SELL";
  type?: string;
  quoteOrderQty?: string;
  quantity?: string;
}): Promise<Record<string, unknown>> {
  const ACCESS_KEY = process.env.MEXC_ACCESS_KEY || "";
  const SECRET_KEY = process.env.MEXC_SECRET_KEY || "";
  if (!ACCESS_KEY || !SECRET_KEY) throw new Error("MEXC API keys not configured");

  const { createHmac } = await import("crypto");
  const qs = new URLSearchParams({
    symbol: params.symbol,
    side: params.side,
    type: params.type || "MARKET",
    timestamp: String(Date.now()),
  });
  if (params.quoteOrderQty) qs.set("quoteOrderQty", params.quoteOrderQty);
  if (params.quantity) qs.set("quantity", params.quantity);
  qs.set("signature", createHmac("sha256", SECRET_KEY).update(qs.toString()).digest("hex"));

  const r = await fetch(`${MEXC_BASE}/api/v3/order?${qs.toString()}`, {
    method: "POST",
    headers: { "X-MEXC-APIKEY": ACCESS_KEY, "Content-Type": "application/json" },
    signal: AbortSignal.timeout(10000),
  });
  const data = await r.json() as Record<string, unknown>;
  if (!r.ok) throw new Error(`MEXC ${r.status}: ${JSON.stringify(data)}`);
  return data;
}

async function getMexcFogoPrice(): Promise<number> {
  try {
    const r = await fetch(`${MEXC_BASE}/api/v3/ticker/price?symbol=FOGOUSDT`, {
      signal: AbortSignal.timeout(5000),
    });
    if (!r.ok) return 0;
    const data = await r.json() as { price: string };
    return parseFloat(data.price) || 0;
  } catch { return 0; }
}

router.get("/status", (_req, res) => {
  const ready = walletReady();
  let address = "";
  try { address = getWalletAddress(); } catch {}
  res.json({
    connected: ready,
    address: address || EXCHANGE_DEPOSIT_ADDRESSES.VALIANT,
    network: "Fogo Mainnet",
    rpc: FOGO_RPC,
    dex: "Valiant DEX",
    blockTime: "40ms",
    signing: ready ? "active" : "no-seed",
    explorer: FOGO_EXPLORER,
    depositAddresses: EXCHANGE_DEPOSIT_ADDRESSES,
  });
});

router.get("/balance", async (_req, res) => {
  try {
    const address = getWalletAddress();
    const [fogoNative, tokens] = await Promise.all([
      getFogoBalance().catch(() => 0),
      getFogoTokenAccounts().catch((): TokenAccount[] => []),
    ]);

    res.json({
      address,
      network: "Fogo Mainnet",
      rpc: FOGO_RPC,
      dex: "Valiant DEX",
      fogo: fogoNative,
      tokens,
      status: "ok",
      depositAddresses: EXCHANGE_DEPOSIT_ADDRESSES,
      timestamp: new Date().toISOString(),
    });
  } catch (err: any) {
    res.json({
      address: EXCHANGE_DEPOSIT_ADDRESSES.VALIANT,
      network: "Fogo Mainnet",
      fogo: 0,
      tokens: [],
      status: "error",
      error: err.message,
      timestamp: new Date().toISOString(),
    });
  }
});

router.get("/wallet-info", async (_req, res) => {
  try {
    const address = getWalletAddress();
    const [fogoNative, tokens, mexcPrice] = await Promise.all([
      getFogoBalance(),
      getFogoTokenAccounts(),
      getMexcFogoPrice(),
    ]);
    const fogoValueUsd = fogoNative * mexcPrice;
    res.json({
      address,
      fogo: fogoNative,
      fogoValueUsd,
      mexcPrice,
      tokens,
      ready: walletReady(),
      network: "Fogo Mainnet",
      depositAddresses: EXCHANGE_DEPOSIT_ADDRESSES,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post("/transfer", async (req, res): Promise<void> => {
  if (!walletReady()) {
    res.status(503).json({ error: "Wallet not configured" });
    return;
  }
  try {
    const { toAddress, exchange, amount } = req.body;
    const validAmount = validateAmount(amount);
    if (!validAmount || (!toAddress && !exchange)) {
      res.status(400).json({ error: "Valid positive amount + (toAddress or exchange) required" });
      return;
    }
    if (exchange && !VALID_EXCHANGES.includes(String(exchange).toUpperCase())) {
      res.status(400).json({ error: `Invalid exchange. Valid: ${VALID_EXCHANGES.join(", ")}` });
      return;
    }

    const result = exchange
      ? await transferFogoToExchange(exchange, validAmount)
      : await transferFogo(toAddress, validAmount);

    res.json({
      ...result,
      network: "Fogo Mainnet",
      amount: Number(amount),
      destination: exchange || toAddress,
      timestamp: new Date().toISOString(),
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post("/execute-arbitrage", async (req, res): Promise<void> => {
  if (!walletReady()) {
    res.status(503).json({ error: "Wallet not configured" });
    return;
  }
  try {
    const {
      buyExchange,
      sellExchange,
      capitalUsd,
      fogoAmount,
    } = req.body;
    const symbol = "FOGOUSDT";

    const validCapital = capitalUsd ? validateAmount(capitalUsd) : null;
    const validFogo = fogoAmount ? validateAmount(fogoAmount) : null;
    if (!validCapital && !validFogo) {
      res.status(400).json({ error: "Valid positive capitalUsd or fogoAmount required" });
      return;
    }

    const mexcPrice = await getMexcFogoPrice();
    if (!mexcPrice) {
      res.status(503).json({ error: "Cannot fetch FOGO price from MEXC" });
      return;
    }

    const fogoQty = validFogo
      ? validFogo
      : (validCapital as number) / mexcPrice;

    const results: Record<string, unknown> = {
      symbol,
      capitalUsd: capitalUsd || fogoQty * mexcPrice,
      fogoQty,
      mexcPrice,
      buyExchange,
      sellExchange,
      network: "Fogo Mainnet",
      blockTime: "40ms",
      timestamp: new Date().toISOString(),
    };

    const buy = (buyExchange || "").toUpperCase();
    const sell = (sellExchange || "").toUpperCase();

    if (buy === "MEXC" || buy === "") {
      try {
        const orderResult = await mexcOrder({
          symbol: "FOGOUSDT",
          side: "BUY",
          type: "MARKET",
          quoteOrderQty: (fogoQty * mexcPrice).toFixed(2),
        });
        results.buyResult = { ...orderResult, exchange: "MEXC", status: "confirmed" };
      } catch (e: any) {
        results.buyResult = { status: "failed", error: e.message, exchange: "MEXC" };
      }
    }

    if (buy.includes("VALIANT") || buy.includes("DEX")) {
      const walletBalance = await getFogoBalance().catch(() => 0);
      results.buyResult = {
        status: walletBalance >= fogoQty ? "ready" : "insufficient_balance",
        exchange: "Valiant DEX",
        walletBalance,
        needed: fogoQty,
        note: walletBalance >= fogoQty
          ? "FOGO ready to transfer from Valiant wallet"
          : `Need ${(fogoQty - walletBalance).toFixed(4)} more FOGO in wallet`,
      };
    }

    if (sell === "MEXC") {
      const mexcAddr = getExchangeAddress("MEXC");
      try {
        const walletBalance = await getFogoBalance().catch(() => 0);
        if (walletBalance >= fogoQty) {
          const txResult = await transferFogo(mexcAddr, fogoQty);
          results.transferResult = { ...txResult, destination: "MEXC", fogoSent: fogoQty };

          if (txResult.status === "confirmed") {
            try {
              const sellResult = await mexcOrder({
                symbol: "FOGOUSDT",
                side: "SELL",
                type: "MARKET",
                quantity: fogoQty.toFixed(2),
              });
              results.sellResult = { ...sellResult, exchange: "MEXC", status: "confirmed" };
            } catch (e: any) {
              results.sellResult = {
                status: "transfer_done_sell_pending",
                error: e.message,
                note: "FOGO transferred to MEXC — sell after deposit confirms",
              };
            }
          }
        } else {
          results.sellResult = {
            status: "insufficient_balance",
            walletBalance,
            needed: fogoQty,
          };
        }
      } catch (e: any) {
        results.sellResult = { status: "failed", error: e.message };
      }
    }

    if (sell.includes("BINANCE")) {
      try {
        const walletBalance = await getFogoBalance().catch(() => 0);
        if (walletBalance >= fogoQty) {
          const txResult = await transferFogoToExchange("BINANCE", fogoQty);
          results.sellResult = { ...txResult, destination: "Binance", fogoSent: fogoQty };
        } else {
          results.sellResult = { status: "insufficient_balance", walletBalance, needed: fogoQty };
        }
      } catch (e: any) {
        results.sellResult = { status: "failed", error: e.message };
      }
    }

    if (sell.includes("KUCOIN")) {
      try {
        const walletBalance = await getFogoBalance().catch(() => 0);
        if (walletBalance >= fogoQty) {
          const txResult = await transferFogoToExchange("KUCOIN", fogoQty);
          results.sellResult = { ...txResult, destination: "KuCoin", fogoSent: fogoQty };
        } else {
          results.sellResult = { status: "insufficient_balance", walletBalance, needed: fogoQty };
        }
      } catch (e: any) {
        results.sellResult = { status: "failed", error: e.message };
      }
    }

    const anyConfirmed =
      (results.buyResult as any)?.status === "confirmed" ||
      (results.sellResult as any)?.status === "confirmed" ||
      (results.transferResult as any)?.status === "confirmed";

    res.json({ ...results, overallStatus: anyConfirmed ? "confirmed" : "pending" });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
