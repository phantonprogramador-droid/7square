import { Router, type IRouter } from "express";
import healthRouter from "./health";
import cryptoRouter from "./crypto";
import mexcRouter from "./mexc";
import okxRouter from "./okx";
import binanceRouter from "./binance";
import kucoinRouter from "./kucoin";
import dexRouter from "./dex";
import balancesRouter from "./balances";
import valiantRouter from "./valiant";
import autotradeRouter from "./autotrade";

const router: IRouter = Router();

router.use(healthRouter);
router.use("/crypto", cryptoRouter);
router.use("/mexc", mexcRouter);
router.use("/okx", okxRouter);
router.use("/binance", binanceRouter);
router.use("/kucoin", kucoinRouter);
router.use("/dex", dexRouter);
router.use("/balances", balancesRouter);
router.use("/valiant", valiantRouter);
router.use("/autotrade", autotradeRouter);

export default router;
