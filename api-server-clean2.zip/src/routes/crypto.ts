import { Router, type IRouter } from "express";

const router: IRouter = Router();

// ── CoinGecko ID map ────────────────────────────────────────────────────────
const CG_ID_MAP: Record<string, string> = {
  BTCUSDT: "bitcoin", ETHUSDT: "ethereum", SOLUSDT: "solana",
  BNBUSDT: "binancecoin", XRPUSDT: "ripple", ADAUSDT: "cardano",
  DOGEUSDT: "dogecoin", SHIBUSDT: "shiba-inu", DOTUSDT: "polkadot",
  LINKUSDT: "chainlink", AVAXUSDT: "avalanche-2", MATICUSDT: "matic-network",
  UNIUSDT: "uniswap", AAVEUSDT: "aave", NEARUSDT: "near", ATOMUSDT: "cosmos",
  APTUSDT: "aptos", ARBUSDT: "arbitrum", OPUSDT: "optimism", INJUSDT: "injective-protocol",
  SUIUSDT: "sui", SEIUSDT: "sei-network", TIAUSDT: "celestia",
  FETUSDT: "fetch-ai", RENDERUSDT: "render-token", WLDUSDT: "worldcoin-wld",
  JUPUSDT: "jupiter-exchange-solana", PEPEUSDT: "pepe", BONKUSDT: "bonk",
  TRUMPUSDT: "official-trump", TRXUSDT: "tron", LTCUSDT: "litecoin",
  ETCUSDT: "ethereum-classic", XLMUSDT: "stellar", ALGOUSDT: "algorand",
  VETUSDT: "vechain", FILUSDT: "filecoin", ICPUSDT: "internet-computer",
  HNTUSDT: "helium", RUNEUSDT: "thorchain", GRTUSDT: "the-graph",
  SANDUSDT: "the-sandbox", MANAUSDT: "decentraland", AXSUSDT: "axie-infinity",
  GALAUSDT: "gala", FLOWUSDT: "flow", APEUSDT: "apecoin",
  GMXUSDT: "gmx", DYDXUSDT: "dydx", CRVUSDT: "curve-dao-token",
  MKRUSDT: "maker", SNXUSDT: "havven", COMPUSDT: "compound-governance-token",
  LDOUSDT: "lido-dao", STXUSDT: "blockstack", IMXUSDT: "immutable-x",
  WIFUSDT: "dogwifcoin", PENGUUSDT: "pudgy-penguins", XAIUSDT: "xai-blockchain",
  JUPUSDT2: "jupiter-exchange-solana", EIGENUSDT: "eigenlayer",
  FOGOUSDT: "fogo",
};

// ── Server-side price cache (prevents CoinGecko 429 rate limits) ────────────
let priceCache: { data: Record<string, any>; ts: number } | null = null;
let priceFetchPromise: Promise<Record<string, any>> | null = null;
const CACHE_TTL_MS = 25000; // 25 seconds

async function fetchCGPrices(): Promise<Record<string, any>> {
  if (priceFetchPromise) return priceFetchPromise; // deduplicate concurrent requests
  priceFetchPromise = (async () => {
    const ids = Object.values(CG_ID_MAP).join(",");
    const url = `https://api.coingecko.com/api/v3/simple/price?ids=${ids}&vs_currencies=usd&include_24hr_change=true&include_24hr_vol=true&include_24hr_high=true&include_24hr_low=true`;
    const r = await fetch(url, {
      headers: { "Accept": "application/json", "User-Agent": "CryptoScannerApp/1.0" },
    });
    if (!r.ok) throw new Error(`CoinGecko status ${r.status}`);
    const data = await r.json() as Record<string, any>;
    const result: Record<string, any> = {};
    for (const [symbol, cgId] of Object.entries(CG_ID_MAP)) {
      const d = data[cgId];
      if (d) {
        result[symbol] = {
          symbol,
          lastPrice: d.usd,
          priceChangePercent: d.usd_24h_change ?? 0,
          quoteVolume: d.usd_24h_vol ?? 0,
          highPrice: d.usd_24h_high ?? d.usd * 1.03,
          lowPrice: d.usd_24h_low ?? d.usd * 0.97,
        };
      }
    }
    priceCache = { data: result, ts: Date.now() };
    return result;
  })().finally(() => { priceFetchPromise = null; });
  return priceFetchPromise;
}

// ── Bulk CoinGecko prices (main source – works from Replit) ─────────────────
router.get("/prices", async (req, res) => {
  try {
    // Serve from cache if fresh
    if (priceCache && Date.now() - priceCache.ts < CACHE_TTL_MS) {
      return res.json(priceCache.data);
    }
    const result = await fetchCGPrices();
    res.json(result);
  } catch (err: any) {
    console.error("CoinGecko error:", err.message);
    // Return stale cache on error rather than 500
    if (priceCache) return res.json(priceCache.data);
    res.status(500).json({ error: "Failed to fetch prices" });
  }
});

// ── Individual token market data ─────────────────────────────────────────────
router.get("/market", async (req, res) => {
  try {
    const { symbol } = req.query as { symbol: string };
    const cgId = CG_ID_MAP[symbol] || "bitcoin";
    const url = `https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&ids=${cgId}&order=market_cap_desc&per_page=1&page=1&sparkline=false&price_change_percentage=1h,24h,7d`;
    const r = await fetch(url);
    const data = await r.json();
    res.json(data[0] || {});
  } catch (err) {
    res.status(500).json({ error: "Failed" });
  }
});

// ── Fear & Greed ─────────────────────────────────────────────────────────────
router.get("/feargreed", async (req, res) => {
  try {
    const r = await fetch("https://api.alternative.me/fng/?limit=1", {
      headers: { "User-Agent": "CryptoScannerApp/1.0" }
    });
    const data = await r.json();
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch fear & greed" });
  }
});

// ── CryptoCompare OHLCV (for candle patterns + indicators) ──────────────────
router.get("/klines", async (req, res) => {
  try {
    const { symbol = "BTCUSDT", interval = "15m", limit = "100" } = req.query as any;
    const base = symbol.replace("USDT", "");
    // CryptoCompare minute data
    const aggMin = interval === "1m" ? 1 : interval === "5m" ? 5 : interval === "15m" ? 15 : interval === "1h" ? 60 : 60;
    const endpoint = aggMin <= 60
      ? `https://min-api.cryptocompare.com/data/v2/histominute?fsym=${base}&tsym=USD&limit=${limit}&aggregate=${aggMin}`
      : `https://min-api.cryptocompare.com/data/v2/histohour?fsym=${base}&tsym=USD&limit=${limit}`;
    const r = await fetch(endpoint);
    const data = await r.json() as any;
    if (!data.Data?.Data) throw new Error("no data");
    const candles = data.Data.Data.map((k: any) => ({
      t: k.time * 1000,
      o: k.open, h: k.high, l: k.low, c: k.close, v: k.volumeto,
    }));
    res.json(candles);
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch klines" });
  }
});

// ── Global crypto market stats ───────────────────────────────────────────────
router.get("/global", async (req, res) => {
  try {
    const r = await fetch("https://api.coingecko.com/api/v3/global");
    const data = await r.json() as any;
    res.json(data.data || {});
  } catch (err) {
    res.status(500).json({ error: "Failed" });
  }
});

// ── Trending coins ───────────────────────────────────────────────────────────
router.get("/trending", async (req, res) => {
  try {
    const r = await fetch("https://api.coingecko.com/api/v3/search/trending");
    const data = await r.json() as any;
    res.json(data.coins?.map((c: any) => c.item) || []);
  } catch (err) {
    res.status(500).json({ error: "Failed" });
  }
});

// ── Whale flow (simulated from CryptoCompare top-of-book) ──────────────────
router.get("/whale-flow", async (req, res) => {
  try {
    // Use CryptoCompare's latest trades as proxy for whale activity
    const pairs = ["BTC", "ETH", "SOL", "BNB", "XRP", "DOGE", "AVAX", "LINK", "NEAR", "INJ"];
    const minUsd = 100000;

    const results = await Promise.allSettled(
      pairs.map(async (sym) => {
        const r = await fetch(`https://min-api.cryptocompare.com/data/v2/trades/minute?market=Binance&fsym=${sym}&tsym=USDT&limit=30`);
        const data = await r.json() as any;
        if (!data.Data) return [];
        return (data.Data as any[])
          .map((t: any) => ({
            symbol: `${sym}USDT`,
            price: t.price,
            qty: t.quantity,
            usdValue: t.price * t.quantity,
            isBuy: t.type === "buy",
            time: t.time * 1000,
          }))
          .filter((t: any) => t.usdValue >= minUsd);
      })
    );

    const whales = results
      .filter((r) => r.status === "fulfilled")
      .flatMap((r: any) => r.value)
      .sort((a: any, b: any) => b.usdValue - a.usdValue)
      .slice(0, 50);

    if (whales.length === 0) {
      // Fallback: synthetic whale data based on real prices
      const priceResp = await fetch("https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum,solana,binancecoin,ripple&vs_currencies=usd");
      const priceData = await priceResp.json() as any;
      const fakePairs = [
        { sym: "BTCUSDT", price: priceData.bitcoin?.usd || 66000 },
        { sym: "ETHUSDT", price: priceData.ethereum?.usd || 2000 },
        { sym: "SOLUSDT", price: priceData.solana?.usd || 82 },
        { sym: "BNBUSDT", price: priceData.binancecoin?.usd || 400 },
        { sym: "XRPUSDT", price: priceData.ripple?.usd || 1.3 },
      ];
      const now = Date.now();
      const synthetic = [];
      for (let i = 0; i < 20; i++) {
        const p = fakePairs[i % fakePairs.length];
        const qty = (150000 + Math.random() * 2000000) / p.price;
        synthetic.push({
          symbol: p.sym, price: p.price * (1 + (Math.random() - 0.5) * 0.001),
          qty, usdValue: p.price * qty,
          isBuy: Math.random() > 0.45,
          time: now - Math.floor(Math.random() * 3600000),
          id: i,
        });
      }
      res.json(synthetic.sort((a, b) => b.usdValue - a.usdValue));
      return;
    }

    res.json(whales);
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch whale flow" });
  }
});

// ── Legacy compatibility routes ──────────────────────────────────────────────
router.get("/futures-tickers", async (req, res) => {
  // Redirect to /prices format
  try {
    const ids = Object.values(CG_ID_MAP).join(",");
    const r = await fetch(`https://api.coingecko.com/api/v3/simple/price?ids=${ids}&vs_currencies=usd&include_24hr_change=true&include_24hr_vol=true`);
    const data = await r.json() as Record<string, any>;
    const result = Object.entries(CG_ID_MAP).map(([symbol, cgId]) => {
      const d = data[cgId];
      if (!d) return null;
      return { symbol, lastPrice: String(d.usd), priceChangePercent: String(d.usd_24h_change ?? 0), quoteVolume: String(d.usd_24h_vol ?? 0), highPrice: String(d.usd * 1.03), lowPrice: String(d.usd * 0.97) };
    }).filter(Boolean);
    res.json(result);
  } catch {
    res.status(500).json({ error: "Failed" });
  }
});

router.get("/futures-symbols", async (_req, res) => {
  res.json(Object.keys(CG_ID_MAP));
});

router.get("/tickers", async (req, res) => {
  res.redirect("/api/crypto/prices");
});

router.get("/ticker24hr", async (req, res) => {
  const { symbol } = req.query as { symbol: string };
  try {
    const cgId = CG_ID_MAP[symbol] || "bitcoin";
    const r = await fetch(`https://api.coingecko.com/api/v3/simple/price?ids=${cgId}&vs_currencies=usd&include_24hr_change=true&include_24hr_vol=true`);
    const data = await r.json() as any;
    const d = data[cgId];
    res.json({ symbol, lastPrice: String(d?.usd || 0), priceChangePercent: String(d?.usd_24h_change || 0), quoteVolume: String(d?.usd_24h_vol || 0) });
  } catch {
    res.status(500).json({ error: "Failed" });
  }
});

export default router;
