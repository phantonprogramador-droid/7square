import { Router, type IRouter } from "express";
import crypto from "crypto";

const router: IRouter = Router();

const PHANTOM_ADDRESS = "GSxJyS7dNHFFLM2kbdGN9AkzvcDuNofDXzUHU2jyVkd3";
const SOLANA_RPC = "https://api.mainnet-beta.solana.com";

async function getValiantBalance(): Promise<{ sol: number; usdc: number; tokens: Array<{ symbol: string; uiAmount: number; mint: string }>; status: string }> {
  try {
    const getSol = fetch(SOLANA_RPC, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ jsonrpc: "2.0", id: 1, method: "getBalance", params: [PHANTOM_ADDRESS, { commitment: "confirmed" }] }),
      signal: AbortSignal.timeout(8000),
    }).then((r) => r.json()) as Promise<{ result: { value: number } }>;

    const getTokens = fetch(SOLANA_RPC, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ jsonrpc: "2.0", id: 2, method: "getTokenAccountsByOwner", params: [PHANTOM_ADDRESS, { programId: "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA" }, { encoding: "jsonParsed" }] }),
      signal: AbortSignal.timeout(8000),
    }).then((r) => r.json()) as Promise<{ result: { value: Array<{ account: { data: { parsed: { info: { mint: string; tokenAmount: { uiAmount: number } } } } } }> } }>;

    const KNOWN: Record<string, string> = {
      "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v": "USDC",
      "Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB": "USDT",
    };

    const [solResp, tokenResp] = await Promise.all([getSol, getTokens]);
    const sol = ((solResp?.result?.value ?? 0) / 1e9);
    const tokens = (tokenResp?.result?.value ?? []).map((acc: any) => {
      const info = acc.account?.data?.parsed?.info;
      return { mint: info?.mint ?? "", symbol: KNOWN[info?.mint ?? ""] ?? "UNKNOWN", uiAmount: info?.tokenAmount?.uiAmount ?? 0 };
    }).filter((t: any) => t.uiAmount > 0);

    const usdc = tokens.filter((t: any) => t.symbol === "USDC" || t.symbol === "USDT").reduce((s: number, t: any) => s + t.uiAmount, 0);
    return { sol: parseFloat(sol.toFixed(6)), usdc: parseFloat(usdc.toFixed(2)), tokens, status: "ok" };
  } catch (e: any) {
    return { sol: 0, usdc: 0, tokens: [], status: "error" };
  }
}

const MEXC_BASE = "https://api.mexc.com";
const MEXC_KEY = process.env.MEXC_ACCESS_KEY || "";
const MEXC_SECRET = process.env.MEXC_SECRET_KEY || "";

const BINANCE_BASES = ["https://api1.binance.com", "https://api2.binance.com", "https://api3.binance.com"];
const BIN_KEY = process.env.BINANCE_API_KEY || "";
const BIN_SECRET = process.env.BINANCE_SECRET_KEY || "";

const OKX_BASE = "https://www.okx.com";
const OKX_KEY = process.env.OKX_API_KEY || "";
const OKX_SECRET = process.env.OKX_SECRET_KEY || "";
const OKX_PASS = process.env.OKX_PASSPHRASE || "";

async function getMexcUsdt(): Promise<{ usdt: number; assets: Record<string, number> }> {
  const ts = String(Date.now());
  const qs = `timestamp=${ts}`;
  const sig = crypto.createHmac("sha256", MEXC_SECRET).update(qs).digest("hex");
  const url = `${MEXC_BASE}/api/v3/account?${qs}&signature=${sig}`;
  const r = await fetch(url, {
    headers: { "X-MEXC-APIKEY": MEXC_KEY },
    signal: AbortSignal.timeout(8000),
  });
  if (!r.ok) throw new Error(`MEXC ${r.status}`);
  const data = await r.json() as { balances: { asset: string; free: string; locked: string }[] };
  const assets: Record<string, number> = {};
  for (const b of data.balances || []) {
    const total = parseFloat(b.free) + parseFloat(b.locked);
    if (total > 0) assets[b.asset] = parseFloat(total.toFixed(6));
  }
  const usdt = (assets["USDT"] || 0) + (assets["USDC"] || 0);
  return { usdt: parseFloat(usdt.toFixed(2)), assets };
}

async function getBinanceUsdt(): Promise<{ usdt: number; assets: Record<string, number>; reachable: boolean }> {
  const ts = String(Date.now());
  const qs = `timestamp=${ts}`;
  const sig = crypto.createHmac("sha256", BIN_SECRET).update(qs).digest("hex");

  for (const base of BINANCE_BASES) {
    try {
      const url = `${base}/api/v3/account?${qs}&signature=${sig}`;
      const r = await fetch(url, {
        headers: { "X-MBX-APIKEY": BIN_KEY },
        signal: AbortSignal.timeout(5000),
      });
      if (r.status === 451) continue;
      if (!r.ok) throw new Error(`Binance ${r.status}`);
      const data = await r.json() as { balances: { asset: string; free: string; locked: string }[] };
      const assets: Record<string, number> = {};
      for (const b of data.balances || []) {
        const total = parseFloat(b.free) + parseFloat(b.locked);
        if (total > 0) assets[b.asset] = parseFloat(total.toFixed(6));
      }
      const usdt = (assets["USDT"] || 0) + (assets["USDC"] || 0);
      return { usdt: parseFloat(usdt.toFixed(2)), assets, reachable: true };
    } catch { continue; }
  }
  return { usdt: 0, assets: {}, reachable: false };
}

async function getOkxUsdt(): Promise<{ usdt: number; assets: Record<string, number> }> {
  if (!OKX_KEY || !OKX_SECRET) return { usdt: 0, assets: {} };
  const ts = new Date().toISOString();
  const path = "/api/v5/account/balance";
  const prehash = ts + "GET" + path;
  const sig = crypto.createHmac("sha256", OKX_SECRET).update(prehash).digest("base64");
  const url = `${OKX_BASE}${path}`;
  const r = await fetch(url, {
    headers: {
      "OK-ACCESS-KEY": OKX_KEY,
      "OK-ACCESS-SIGN": sig,
      "OK-ACCESS-TIMESTAMP": ts,
      "OK-ACCESS-PASSPHRASE": OKX_PASS,
    },
    signal: AbortSignal.timeout(8000),
  });
  if (!r.ok) throw new Error(`OKX ${r.status}`);
  const data = await r.json() as any;
  const details = data?.data?.[0]?.details || [];
  const assets: Record<string, number> = {};
  for (const d of details) {
    const total = parseFloat(d.cashBal || "0");
    if (total > 0) assets[d.ccy] = parseFloat(total.toFixed(6));
  }
  const usdt = (assets["USDT"] || 0) + (assets["USDC"] || 0);
  return { usdt: parseFloat(usdt.toFixed(2)), assets };
}

async function getMexcOpenOrders(): Promise<any[]> {
  const ts = String(Date.now());
  const qs = `timestamp=${ts}`;
  const sig = crypto.createHmac("sha256", MEXC_SECRET).update(qs).digest("hex");
  const url = `${MEXC_BASE}/api/v3/openOrders?${qs}&signature=${sig}`;
  const r = await fetch(url, {
    headers: { "X-MEXC-APIKEY": MEXC_KEY },
    signal: AbortSignal.timeout(8000),
  });
  if (!r.ok) return [];
  return r.json();
}

async function getMexcMyTrades(limit = 20): Promise<any[]> {
  const ts = String(Date.now());
  const qs = `limit=${limit}&timestamp=${ts}`;
  const sig = crypto.createHmac("sha256", MEXC_SECRET).update(qs).digest("hex");
  const url = `${MEXC_BASE}/api/v3/myTrades?${qs}&signature=${sig}`;
  const r = await fetch(url, {
    headers: { "X-MEXC-APIKEY": MEXC_KEY },
    signal: AbortSignal.timeout(8000),
  });
  if (!r.ok) return [];
  return r.json();
}

router.get("/", async (_req, res) => {
  const results = await Promise.allSettled([
    getMexcUsdt(),
    getBinanceUsdt(),
    getOkxUsdt(),
    getValiantBalance(),
  ]);

  const mexc = results[0].status === "fulfilled" ? results[0].value : { usdt: 0, assets: {} };
  const binance = results[1].status === "fulfilled" ? results[1].value : { usdt: 0, assets: {}, reachable: false };
  const okx = results[2].status === "fulfilled" ? results[2].value : { usdt: 0, assets: {} };
  const valiant = results[3].status === "fulfilled" ? results[3].value : { sol: 0, usdc: 0, tokens: [], status: "error" };

  const total = (mexc.usdt || 0) + (binance.usdt || 0) + (okx.usdt || 0) + ((valiant as any).usdc || 0);

  res.json({
    exchanges: {
      MEXC: { usdt: mexc.usdt, assets: mexc.assets, status: results[0].status === "fulfilled" ? "ok" : "error" },
      Binance: { usdt: binance.usdt, assets: (binance as any).assets || {}, status: (binance as any).reachable ? "ok" : "geo-blocked", reachable: (binance as any).reachable },
      OKX: { usdt: okx.usdt, assets: okx.assets, status: results[2].status === "fulfilled" ? "ok" : "error" },
      Valiant: {
        usdt: (valiant as any).usdc || 0,
        assets: {
          SOL: (valiant as any).sol || 0,
          USDC: (valiant as any).usdc || 0,
          ...Object.fromEntries(((valiant as any).tokens || []).map((t: any) => [t.symbol, t.uiAmount])),
        },
        status: (valiant as any).status || "error",
        sol: (valiant as any).sol || 0,
        address: PHANTOM_ADDRESS,
        network: "Solana Mainnet",
        dex: "Valiant DEX",
      },
    },
    totalUsdt: parseFloat(total.toFixed(2)),
    timestamp: new Date().toISOString(),
    binanceDepositUsdc: {
      address: "0xc08d8edc52482a2bd0a290a3ad451b3379c15b10",
      network: "BSC (BEP20)",
      asset: "USDC",
    },
  });
});

router.get("/open-orders", async (_req, res) => {
  try {
    const orders = await getMexcOpenOrders();
    res.json({ orders: Array.isArray(orders) ? orders : [], exchange: "MEXC", timestamp: new Date().toISOString() });
  } catch (err: any) {
    res.json({ orders: [], exchange: "MEXC", error: err.message });
  }
});

router.get("/recent-trades", async (req, res) => {
  const limit = parseInt((req.query.limit as string) || "20");
  try {
    const trades = await getMexcMyTrades(limit);
    res.json({ trades: Array.isArray(trades) ? trades : [], exchange: "MEXC", timestamp: new Date().toISOString() });
  } catch (err: any) {
    res.json({ trades: [], exchange: "MEXC", error: err.message });
  }
});

export default router;
