import { Router, type IRouter } from "express";
import {
  walletReady,
  getFogoBalance,
  getWalletAddress,
  transferFogoToExchange,
  FOGO_RPC,
} from "../lib/solanaWallet.js";

const router: IRouter = Router();

const MEXC_BASE = "https://api.mexc.com";

let cycleLock = false;
let lastCycleTime = 0;
const MIN_CYCLE_INTERVAL_MS = 20000;

const ALLOWED_SYMBOLS = /^[A-Z0-9]{2,12}USDT$/;
const ALLOWED_SIDES = ["BUY", "SELL"] as const;

async function mexcSignedOrder(params: {
  symbol: string;
  side: "BUY" | "SELL";
  type?: string;
  quoteOrderQty?: string;
  quantity?: string;
}): Promise<Record<string, unknown>> {
  if (!ALLOWED_SYMBOLS.test(params.symbol)) throw new Error(`Invalid symbol: ${params.symbol}`);
  if (!ALLOWED_SIDES.includes(params.side)) throw new Error(`Invalid side: ${params.side}`);

  const ACCESS_KEY = process.env.MEXC_ACCESS_KEY || "";
  const SECRET_KEY = process.env.MEXC_SECRET_KEY || "";
  if (!ACCESS_KEY || !SECRET_KEY) throw new Error("MEXC API keys not configured");

  const { createHmac } = await import("crypto");
  const qs = new URLSearchParams({
    symbol: params.symbol,
    side: params.side,
    type: params.type || "MARKET",
    timestamp: String(Date.now()),
  });
  if (params.quoteOrderQty) qs.set("quoteOrderQty", params.quoteOrderQty);
  if (params.quantity) qs.set("quantity", params.quantity);
  qs.set("signature", createHmac("sha256", SECRET_KEY).update(qs.toString()).digest("hex"));

  const r = await fetch(`${MEXC_BASE}/api/v3/order?${qs.toString()}`, {
    method: "POST",
    headers: { "X-MEXC-APIKEY": ACCESS_KEY, "Content-Type": "application/json" },
  });
  const data = await r.json() as Record<string, unknown>;
  if (!r.ok) throw new Error(`MEXC ${r.status}: ${JSON.stringify(data)}`);
  return data;
}

async function getMexcPrice(symbol: string): Promise<number> {
  try {
    const r = await fetch(`${MEXC_BASE}/api/v3/ticker/price?symbol=${symbol}`);
    if (!r.ok) return 0;
    const data = await r.json() as { price: string };
    return parseFloat(data.price) || 0;
  } catch { return 0; }
}

async function getMexcBalance(asset: string): Promise<number> {
  const ACCESS_KEY = process.env.MEXC_ACCESS_KEY || "";
  const SECRET_KEY = process.env.MEXC_SECRET_KEY || "";
  if (!ACCESS_KEY || !SECRET_KEY) return 0;
  const { createHmac } = await import("crypto");
  const qs = new URLSearchParams({ timestamp: String(Date.now()) });
  qs.set("signature", createHmac("sha256", SECRET_KEY).update(qs.toString()).digest("hex"));
  try {
    const r = await fetch(`${MEXC_BASE}/api/v3/account?${qs.toString()}`, {
      headers: { "X-MEXC-APIKEY": ACCESS_KEY },
    });
    if (!r.ok) return 0;
    const data = await r.json() as any;
    const bal = (data.balances || []).find((b: any) => b.asset === asset);
    return bal ? parseFloat(bal.free) || 0 : 0;
  } catch { return 0; }
}

function normalizeSymbol(raw: string): string {
  let s = raw.replace(/[^A-Z0-9]/gi, "").toUpperCase();
  if (!s.endsWith("USDT") && !s.endsWith("USDC")) {
    s += "USDT";
  }
  return s;
}

interface CycleStep {
  step: string;
  status: "ok" | "error" | "skipped";
  detail: string;
  data?: Record<string, unknown>;
}

router.get("/status", async (_req, res) => {
  const wallet = walletReady();
  const mexcKeys = !!(process.env.MEXC_ACCESS_KEY && process.env.MEXC_SECRET_KEY);
  let walletAddress = "";
  let walletBalance = 0;
  let mexcUsdt = 0;
  let fogoPrice = 0;

  try { walletAddress = getWalletAddress(); } catch {}
  try { walletBalance = await getFogoBalance(); } catch {}
  try { mexcUsdt = await getMexcBalance("USDT"); } catch {}
  try { fogoPrice = await getMexcPrice("FOGOUSDT"); } catch {}

  res.json({
    ready: wallet && mexcKeys,
    wallet: { configured: wallet, address: walletAddress, fogoBalance: walletBalance },
    mexc: { configured: mexcKeys, usdtBalance: mexcUsdt },
    fogoPrice,
    fogoValueUsd: walletBalance * fogoPrice,
    network: "Fogo Mainnet",
    rpc: FOGO_RPC,
  });
});

router.post("/execute-cycle", async (req, res): Promise<void> => {
  const steps: CycleStep[] = [];
  const startTime = Date.now();

  if (cycleLock) {
    res.status(429).json({ error: "Ciclo em execução. Aguarde o ciclo atual terminar.", steps });
    return;
  }

  if (Date.now() - lastCycleTime < MIN_CYCLE_INTERVAL_MS) {
    res.status(429).json({ error: `Rate limit: aguarde ${Math.ceil((MIN_CYCLE_INTERVAL_MS - (Date.now() - lastCycleTime)) / 1000)}s`, steps });
    return;
  }

  cycleLock = true;
  lastCycleTime = Date.now();

  try {
    const {
      fogoAmount,
      squeezeSymbol,
      action = "FULL_CYCLE",
    } = req.body || {};

    if (!walletReady()) {
      res.status(503).json({ error: "Wallet not configured (PHANTOM_SEED_PHRASE)", steps });
      return;
    }

    const ACCESS_KEY = process.env.MEXC_ACCESS_KEY || "";
    const SECRET_KEY = process.env.MEXC_SECRET_KEY || "";
    if (!ACCESS_KEY || !SECRET_KEY) {
      res.status(503).json({ error: "MEXC API keys not configured", steps });
      return;
    }

    const fogoPrice = await getMexcPrice("FOGOUSDT");
    if (!fogoPrice) {
      res.status(503).json({ error: "Cannot fetch FOGO price", steps });
      return;
    }

    const walletBalance = await getFogoBalance();
    steps.push({
      step: "CHECK_BALANCE",
      status: "ok",
      detail: `Wallet: ${walletBalance.toFixed(4)} FOGO ($${(walletBalance * fogoPrice).toFixed(2)})`,
      data: { walletBalance, fogoPrice, valueUsd: walletBalance * fogoPrice },
    });

    const minFogoForTrade = Math.max(Math.ceil(1.5 / fogoPrice), 80);
    const rawAmount = fogoAmount
      ? Math.min(Number(fogoAmount), walletBalance * 0.9)
      : Math.min(walletBalance * 0.10, 200);
    const tradeAmount = Math.max(rawAmount, minFogoForTrade);

    if (tradeAmount > walletBalance * 0.9 || tradeAmount * fogoPrice < 1) {
      res.status(400).json({
        error: `FOGO insuficiente. Min: ${minFogoForTrade} FOGO ($${(minFogoForTrade * fogoPrice).toFixed(2)}). Disponível: ${walletBalance.toFixed(2)}`,
        steps,
      });
      return;
    }

    const tradeValueUsd = tradeAmount * fogoPrice;
    steps.push({
      step: "CALCULATE_SIZE",
      status: "ok",
      detail: `Trade: ${tradeAmount.toFixed(2)} FOGO ($${tradeValueUsd.toFixed(2)}) — ${((tradeAmount / walletBalance) * 100).toFixed(1)}% do wallet`,
      data: { tradeAmount, tradeValueUsd, pctOfWallet: (tradeAmount / walletBalance) * 100 },
    });

    if (action === "FULL_CYCLE" || action === "TRANSFER_TO_MEXC") {
      try {
        const txResult = await transferFogoToExchange("MEXC", tradeAmount);
        steps.push({
          step: "TRANSFER_FOGO_TO_MEXC",
          status: txResult.status === "confirmed" ? "ok" : "error",
          detail: `${tradeAmount.toFixed(2)} FOGO → MEXC | tx: ${txResult.signature.slice(0, 16)}... | ${txResult.latencyMs}ms`,
          data: {
            signature: txResult.signature,
            explorerUrl: txResult.explorerUrl,
            latencyMs: txResult.latencyMs,
            fogoSent: tradeAmount,
          },
        });

        if (txResult.status !== "confirmed") {
          res.json({
            status: "partial",
            error: "Transfer failed on-chain",
            steps,
            elapsed: Date.now() - startTime,
          });
          return;
        }
      } catch (err: any) {
        steps.push({
          step: "TRANSFER_FOGO_TO_MEXC",
          status: "error",
          detail: `Transfer failed: ${err.message}`,
        });
        res.json({ status: "error", error: err.message, steps, elapsed: Date.now() - startTime });
        return;
      }

      if (action === "TRANSFER_TO_MEXC") {
        res.json({ status: "ok", action, steps, elapsed: Date.now() - startTime });
        return;
      }
    }

    if (action === "FULL_CYCLE" || action === "SELL_FOGO") {
      const preDepositFogo = await getMexcBalance("FOGO");
      steps.push({
        step: "WAITING_MEXC_DEPOSIT",
        status: "ok",
        detail: `Aguardando depósito MEXC (${tradeAmount.toFixed(0)} FOGO). Saldo pré: ${preDepositFogo.toFixed(2)}`,
      });

      let depositReady = false;
      for (let attempt = 0; attempt < 12; attempt++) {
        await new Promise(r => setTimeout(r, 5000));
        const mexcFogo = await getMexcBalance("FOGO");
        const delta = mexcFogo - preDepositFogo;
        if (delta >= tradeAmount * 0.90) {
          depositReady = true;
          steps.push({
            step: "DEPOSIT_CONFIRMED",
            status: "ok",
            detail: `Depósito confirmado: +${delta.toFixed(2)} FOGO (total: ${mexcFogo.toFixed(2)}) — tentativa ${attempt + 1}`,
            data: { mexcFogoBalance: mexcFogo, delta, attempts: attempt + 1 },
          });
          break;
        }
      }

      if (!depositReady) {
        steps.push({
          step: "DEPOSIT_TIMEOUT",
          status: "error",
          detail: `Depósito MEXC não confirmado após 60s. FOGO pode estar em trânsito.`,
        });
        res.json({ status: "partial", error: "Deposit not confirmed", steps, elapsed: Date.now() - startTime });
        return;
      }

      try {
        const sellQty = Math.floor(tradeAmount);
        const sellResult = await mexcSignedOrder({
          symbol: "FOGOUSDT",
          side: "SELL",
          type: "MARKET",
          quantity: String(sellQty),
        });
        const executedQty = parseFloat(String(sellResult.executedQty || sellResult.origQty || tradeAmount));
        const cummQuoteQty = parseFloat(String(sellResult.cummulativeQuoteQty || (executedQty * fogoPrice)));
        steps.push({
          step: "SELL_FOGO_MEXC",
          status: "ok",
          detail: `SELL ${executedQty.toFixed(2)} FOGO @ ~$${fogoPrice.toFixed(6)} → $${cummQuoteQty.toFixed(2)} USDT`,
          data: { ...sellResult, executedQty, cummQuoteQty },
        });
      } catch (err: any) {
        steps.push({ step: "SELL_FOGO_MEXC", status: "error", detail: `Sell failed: ${err.message}` });
        res.json({ status: "partial", error: err.message, steps, elapsed: Date.now() - startTime });
        return;
      }

      if (action === "SELL_FOGO") {
        res.json({ status: "ok", action, steps, elapsed: Date.now() - startTime });
        return;
      }
    }

    const targetSymbol = squeezeSymbol ? normalizeSymbol(squeezeSymbol) : "FOGOUSDT";

    if (action === "FULL_CYCLE" && targetSymbol !== "FOGOUSDT") {
      if (!ALLOWED_SYMBOLS.test(targetSymbol)) {
        steps.push({ step: "BUY_SQUEEZE", status: "error", detail: `Símbolo inválido: ${targetSymbol}` });
      } else {
        const usdtBalance = await getMexcBalance("USDT");
        const buyAmount = Math.min(usdtBalance * 0.95, tradeValueUsd * 0.95);

        if (buyAmount < 1) {
          steps.push({ step: "BUY_SQUEEZE", status: "skipped", detail: `USDT insuficiente: $${usdtBalance.toFixed(2)}` });
        } else {
          try {
            const buyResult = await mexcSignedOrder({
              symbol: targetSymbol,
              side: "BUY",
              type: "MARKET",
              quoteOrderQty: buyAmount.toFixed(2),
            });
            steps.push({
              step: "BUY_SQUEEZE",
              status: "ok",
              detail: `BUY ${targetSymbol} com $${buyAmount.toFixed(2)} USDT`,
              data: buyResult,
            });
          } catch (err: any) {
            steps.push({ step: "BUY_SQUEEZE", status: "error", detail: err.message });
          }
        }
      }
    }

    if (action === "FULL_CYCLE") {
      const mexcFogoBalance = await getMexcBalance("FOGO");
      const mexcUsdtBalance = await getMexcBalance("USDT");

      if (mexcUsdtBalance > 1 && targetSymbol === "FOGOUSDT") {
        try {
          const rebuyResult = await mexcSignedOrder({
            symbol: "FOGOUSDT",
            side: "BUY",
            type: "MARKET",
            quoteOrderQty: (mexcUsdtBalance * 0.95).toFixed(2),
          });
          const reboughtQty = parseFloat(String(rebuyResult.executedQty || 0));
          steps.push({
            step: "REBUY_FOGO",
            status: "ok",
            detail: `BUY ${reboughtQty.toFixed(2)} FOGO com $${(mexcUsdtBalance * 0.95).toFixed(2)} USDT`,
            data: rebuyResult,
          });
        } catch (err: any) {
          steps.push({ step: "REBUY_FOGO", status: "error", detail: err.message });
        }
      }

      steps.push({
        step: "CYCLE_COMPLETE",
        status: "ok",
        detail: `Ciclo concluído em ${((Date.now() - startTime) / 1000).toFixed(1)}s`,
        data: {
          mexcFogoBalance,
          mexcUsdtBalance,
          elapsed: Date.now() - startTime,
        },
      });
    }

    res.json({
      status: "ok",
      action,
      steps,
      elapsed: Date.now() - startTime,
    });
  } catch (err: any) {
    steps.push({ step: "UNEXPECTED_ERROR", status: "error", detail: err.message });
    res.status(500).json({ status: "error", error: err.message, steps, elapsed: Date.now() - startTime });
  } finally {
    cycleLock = false;
  }
});

router.post("/mexc-spot-trade", async (req, res): Promise<void> => {
  try {
    const { symbol: rawSymbol, side, quoteOrderQty, quantity } = req.body || {};
    if (!rawSymbol || !side) {
      res.status(400).json({ error: "symbol and side required" });
      return;
    }

    const symbol = normalizeSymbol(rawSymbol);
    if (!ALLOWED_SYMBOLS.test(symbol)) {
      res.status(400).json({ error: `Invalid symbol: ${symbol}` });
      return;
    }
    if (!ALLOWED_SIDES.includes(side)) {
      res.status(400).json({ error: `Invalid side: ${side}` });
      return;
    }

    const params: any = { symbol, side, type: "MARKET" };
    if (quoteOrderQty) params.quoteOrderQty = String(quoteOrderQty);
    if (quantity) params.quantity = String(quantity);

    const result = await mexcSignedOrder(params);
    res.json({ status: "ok", ...result });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
