import { Router, type IRouter } from "express";
import crypto from "crypto";

const router: IRouter = Router();

const OKX_BASE = "https://www.okx.com";
const API_KEY = process.env.OKX_API_KEY || "";
const SECRET_KEY = process.env.OKX_SECRET_KEY || "";
const PASSPHRASE = process.env.OKX_PASSPHRASE || "";

function sign(timestamp: string, method: string, path: string, body: string): string {
  const prehash = timestamp + method + path + body;
  return crypto.createHmac("sha256", SECRET_KEY).update(prehash).digest("base64");
}

function buildHeaders(method: string, path: string, body = ""): Record<string, string> {
  const ts = new Date().toISOString();
  return {
    "OK-ACCESS-KEY": API_KEY,
    "OK-ACCESS-SIGN": sign(ts, method, path, body),
    "OK-ACCESS-TIMESTAMP": ts,
    "OK-ACCESS-PASSPHRASE": PASSPHRASE,
    "Content-Type": "application/json",
  };
}

async function okxGet(path: string, params: Record<string, string> = {}) {
  const qs = new URLSearchParams(params).toString();
  const fullPath = qs ? `${path}?${qs}` : path;
  const url = `${OKX_BASE}${fullPath}`;
  const r = await fetch(url, {
    headers: buildHeaders("GET", fullPath),
    signal: AbortSignal.timeout(8000),
  });
  if (!r.ok) {
    const body = await r.text();
    throw new Error(`OKX ${r.status}: ${body}`);
  }
  return r.json();
}

async function okxPost(path: string, body: Record<string, unknown>) {
  const bodyStr = JSON.stringify(body);
  const url = `${OKX_BASE}${path}`;
  const r = await fetch(url, {
    method: "POST",
    headers: buildHeaders("POST", path, bodyStr),
    body: bodyStr,
    signal: AbortSignal.timeout(8000),
  });
  if (!r.ok) {
    const b = await r.text();
    throw new Error(`OKX ${r.status}: ${b}`);
  }
  return r.json();
}

router.get("/status", (_req, res) => {
  res.json({ connected: !!API_KEY && !!SECRET_KEY && !!PASSPHRASE, exchange: "OKX" });
});

router.get("/account", async (_req, res) => {
  try {
    const data = await okxGet("/api/v5/account/balance");
    res.json(data);
  } catch (err: any) {
    console.error("OKX account error:", err.message);
    res.status(500).json({ error: err.message });
  }
});

router.get("/ticker", async (req, res) => {
  try {
    const { instId } = req.query as { instId?: string };
    const params: Record<string, string> = { instType: "SPOT" };
    if (instId) params.instId = instId;
    const data = await okxGet("/api/v5/market/ticker", params);
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.get("/tickers", async (_req, res) => {
  try {
    const data = await okxGet("/api/v5/market/tickers", { instType: "SPOT" });
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.get("/depth", async (req, res) => {
  try {
    const { instId = "BTC-USDT", sz = "20" } = req.query as any;
    const data = await okxGet("/api/v5/market/books", { instId, sz });
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.get("/klines", async (req, res) => {
  try {
    const { instId = "BTC-USDT", bar = "15m", limit = "100" } = req.query as any;
    const data = await okxGet("/api/v5/market/candles", { instId, bar, limit });
    const raw = (data as any)?.data ?? [];
    const candles = raw.map((k: any) => ({
      t: parseInt(k[0]), o: parseFloat(k[1]), h: parseFloat(k[2]),
      l: parseFloat(k[3]), c: parseFloat(k[4]), v: parseFloat(k[5]),
    }));
    res.json(candles);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.get("/trades", async (req, res) => {
  try {
    const { instId = "BTC-USDT", limit = "50" } = req.query as any;
    const data = await okxGet("/api/v5/market/trades", { instId, limit });
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.get("/open-orders", async (req, res) => {
  try {
    const { instId } = req.query as { instId?: string };
    const params: Record<string, string> = { instType: "SPOT" };
    if (instId) params.instId = instId;
    const data = await okxGet("/api/v5/trade/orders-pending", params);
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.get("/my-trades", async (req, res) => {
  try {
    const { instId, instType = "SPOT" } = req.query as any;
    const params: Record<string, string> = { instType };
    if (instId) params.instId = instId;
    const data = await okxGet("/api/v5/trade/fills", params);
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post("/order", async (req, res): Promise<void> => {
  try {
    const { instId, side, ordType, sz, px } = req.body || {};
    if (!instId || !side || !ordType || !sz) {
      res.status(400).json({ error: "instId, side, ordType, sz required" });
      return;
    }
    const body: Record<string, unknown> = {
      instId,
      tdMode: "cash",
      side: side.toLowerCase(),
      ordType: ordType.toLowerCase(),
      sz: String(sz),
    };
    if (px) body.px = String(px);
    const data = await okxPost("/api/v5/trade/order", body);
    res.json(data);
  } catch (err: any) {
    console.error("OKX order error:", err.message);
    res.status(500).json({ error: err.message });
  }
});

router.post("/cancel-order", async (req, res): Promise<void> => {
  try {
    const { instId, ordId } = req.body || {};
    if (!instId || !ordId) {
      res.status(400).json({ error: "instId, ordId required" });
      return;
    }
    const data = await okxPost("/api/v5/trade/cancel-order", { instId, ordId });
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.get("/fee", async (req, res) => {
  try {
    const { instType = "SPOT" } = req.query as any;
    const data = await okxGet("/api/v5/account/trade-fee", { instType, instId: "BTC-USDT" });
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
