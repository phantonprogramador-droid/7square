import { Router, type IRouter } from "express";
import crypto from "crypto";

const router: IRouter = Router();

const MEXC_BASE = "https://api.mexc.com";
const ACCESS_KEY = process.env.MEXC_ACCESS_KEY || "";
const SECRET_KEY = process.env.MEXC_SECRET_KEY || "";

function sign(queryString: string): string {
  return crypto.createHmac("sha256", SECRET_KEY).update(queryString).digest("hex");
}

function buildHeaders() {
  return {
    "X-MEXC-APIKEY": ACCESS_KEY,
    "Content-Type": "application/json",
  };
}

async function mexcGet(path: string, params: Record<string, string> = {}, signed = false) {
  const qs = new URLSearchParams(params);
  if (signed) {
    qs.set("timestamp", String(Date.now()));
    qs.set("signature", sign(qs.toString()));
  }
  const url = `${MEXC_BASE}${path}?${qs.toString()}`;
  const r = await fetch(url, { headers: buildHeaders() });
  if (!r.ok) {
    const body = await r.text();
    throw new Error(`MEXC ${r.status}: ${body}`);
  }
  return r.json();
}

async function mexcPost(path: string, params: Record<string, string> = {}) {
  const qs = new URLSearchParams(params);
  qs.set("timestamp", String(Date.now()));
  qs.set("signature", sign(qs.toString()));
  const url = `${MEXC_BASE}${path}?${qs.toString()}`;
  const r = await fetch(url, { method: "POST", headers: buildHeaders() });
  if (!r.ok) {
    const body = await r.text();
    throw new Error(`MEXC ${r.status}: ${body}`);
  }
  return r.json();
}

async function mexcDelete(path: string, params: Record<string, string> = {}) {
  const qs = new URLSearchParams(params);
  qs.set("timestamp", String(Date.now()));
  qs.set("signature", sign(qs.toString()));
  const url = `${MEXC_BASE}${path}?${qs.toString()}`;
  const r = await fetch(url, { method: "DELETE", headers: buildHeaders() });
  if (!r.ok) {
    const body = await r.text();
    throw new Error(`MEXC ${r.status}: ${body}`);
  }
  return r.json();
}

router.get("/status", (_req, res) => {
  res.json({ connected: !!ACCESS_KEY && !!SECRET_KEY, exchange: "MEXC" });
});

router.get("/account", async (_req, res) => {
  try {
    const data = await mexcGet("/api/v3/account", {}, true);
    res.json(data);
  } catch (err: any) {
    console.error("MEXC account error:", err.message);
    res.status(500).json({ error: err.message });
  }
});

router.get("/ticker", async (req, res) => {
  try {
    const { symbol } = req.query as { symbol?: string };
    const params: Record<string, string> = {};
    if (symbol) params.symbol = symbol;
    const data = await mexcGet("/api/v3/ticker/24hr", params);
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.get("/depth", async (req, res) => {
  try {
    const { symbol = "BTCUSDT", limit = "20" } = req.query as any;
    const data = await mexcGet("/api/v3/depth", { symbol, limit });
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.get("/klines", async (req, res) => {
  try {
    const { symbol = "BTCUSDT", interval = "15m", limit = "100" } = req.query as any;
    const data = await mexcGet("/api/v3/klines", { symbol, interval, limit });
    const candles = (data as any[]).map((k: any) => ({
      t: k[0], o: parseFloat(k[1]), h: parseFloat(k[2]),
      l: parseFloat(k[3]), c: parseFloat(k[4]), v: parseFloat(k[5]),
    }));
    res.json(candles);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.get("/trades", async (req, res) => {
  try {
    const { symbol = "BTCUSDT", limit = "50" } = req.query as any;
    const data = await mexcGet("/api/v3/trades", { symbol, limit });
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.get("/open-orders", async (req, res) => {
  try {
    const { symbol } = req.query as { symbol?: string };
    const params: Record<string, string> = {};
    if (symbol) params.symbol = symbol;
    const data = await mexcGet("/api/v3/openOrders", params, true);
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.get("/my-trades", async (req, res) => {
  try {
    const { symbol = "BTCUSDT", limit = "20" } = req.query as any;
    const data = await mexcGet("/api/v3/myTrades", { symbol, limit }, true);
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post("/order", async (req, res): Promise<void> => {
  try {
    const { symbol, side, type, quantity, price, quoteOrderQty } = req.body || req.query;
    if (!symbol || !side || !type) {
      res.status(400).json({ error: "symbol, side, type required" });
      return;
    }
    const params: Record<string, string> = { symbol, side, type };
    if (quantity) params.quantity = String(quantity);
    if (price) params.price = String(price);
    if (quoteOrderQty) params.quoteOrderQty = String(quoteOrderQty);
    const data = await mexcPost("/api/v3/order", params);
    res.json(data);
  } catch (err: any) {
    console.error("MEXC order error:", err.message);
    res.status(500).json({ error: err.message });
  }
});

router.delete("/order", async (req, res): Promise<void> => {
  try {
    const { symbol, orderId } = req.query as any;
    if (!symbol || !orderId) {
      res.status(400).json({ error: "symbol, orderId required" });
      return;
    }
    const data = await mexcDelete("/api/v3/order", { symbol, orderId });
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.get("/exchange-info", async (req, res) => {
  try {
    const { symbol } = req.query as { symbol?: string };
    const params: Record<string, string> = {};
    if (symbol) params.symbol = symbol;
    const data = await mexcGet("/api/v3/exchangeInfo", params);
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
