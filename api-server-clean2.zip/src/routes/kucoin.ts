import { Router, type IRouter } from "express";
import crypto from "crypto";

const router: IRouter = Router();

const KUCOIN_BASE = "https://api.kucoin.com";
const API_KEY = process.env.KUCOIN_API_KEY || "";
const API_SECRET = process.env.KUCOIN_SECRET_KEY || "";
const API_PASSPHRASE = process.env.KUCOIN_PASSPHRASE || "";

function signKuCoin(timestamp: string, method: string, path: string, body = ""): string {
  const message = timestamp + method + path + body;
  return crypto.createHmac("sha256", API_SECRET).update(message).digest("base64");
}

function buildHeaders(method: string, path: string, body = ""): Record<string, string> {
  const timestamp = String(Date.now());
  const signature = signKuCoin(timestamp, method, path, body);
  const passphrase = crypto.createHmac("sha256", API_SECRET).update(API_PASSPHRASE).digest("base64");

  return {
    "KC-API-KEY": API_KEY,
    "KC-API-SIGN": signature,
    "KC-API-TIMESTAMP": timestamp,
    "KC-API-PASSPHRASE": passphrase,
    "KC-API-KEY-VERSION": "2",
    "Content-Type": "application/json",
  };
}

async function kucoinGet(path: string, params: Record<string, string> = {}, signed = false) {
  const qs = new URLSearchParams(params);
  const queryStr = qs.toString();
  const fullPath = queryStr ? `${path}?${queryStr}` : path;
  const url = `${KUCOIN_BASE}${fullPath}`;
  const headers = signed ? buildHeaders("GET", fullPath) : { "Content-Type": "application/json" };
  const r = await fetch(url, { headers });
  if (!r.ok) {
    const body = await r.text();
    throw new Error(`KuCoin ${r.status}: ${body}`);
  }
  const data = await r.json();
  return (data as any).data || data;
}

async function kucoinPost(path: string, body: Record<string, any> = {}) {
  const bodyStr = JSON.stringify(body);
  const url = `${KUCOIN_BASE}${path}`;
  const headers = buildHeaders("POST", path, bodyStr);
  const r = await fetch(url, { method: "POST", headers, body: bodyStr });
  if (!r.ok) {
    const respBody = await r.text();
    throw new Error(`KuCoin ${r.status}: ${respBody}`);
  }
  const data = await r.json();
  return (data as any).data || data;
}

async function kucoinDelete(path: string) {
  const url = `${KUCOIN_BASE}${path}`;
  const headers = buildHeaders("DELETE", path);
  const r = await fetch(url, { method: "DELETE", headers });
  if (!r.ok) {
    const body = await r.text();
    throw new Error(`KuCoin ${r.status}: ${body}`);
  }
  const data = await r.json();
  return (data as any).data || data;
}

router.get("/status", (_req, res) => {
  res.json({ connected: !!API_KEY && !!API_SECRET, exchange: "KuCoin" });
});

router.get("/ticker", async (req, res) => {
  try {
    const { symbol } = req.query as { symbol?: string };
    if (symbol) {
      const data = await kucoinGet("/api/v1/market/orderbook/level1", { symbol });
      res.json(data);
    } else {
      const data = await kucoinGet("/api/v1/market/allTickers");
      res.json(data);
    }
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.get("/depth", async (req, res) => {
  try {
    const { symbol = "BTC-USDT" } = req.query as any;
    const data = await kucoinGet(`/api/v1/market/orderbook/level2_20`, { symbol });
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.get("/klines", async (req, res) => {
  try {
    const { symbol = "BTC-USDT", type = "15min", startAt, endAt } = req.query as any;
    const params: Record<string, string> = { symbol, type };
    if (startAt) params.startAt = startAt;
    if (endAt) params.endAt = endAt;
    const data = await kucoinGet("/api/v1/market/candles", params);
    const candles = (data as any[]).map((k: any) => ({
      t: Number(k[0]) * 1000, o: parseFloat(k[1]), c: parseFloat(k[2]),
      h: parseFloat(k[3]), l: parseFloat(k[4]), v: parseFloat(k[5]),
    }));
    res.json(candles);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.get("/account", async (_req, res) => {
  try {
    const data = await kucoinGet("/api/v1/accounts", {}, true);
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.get("/open-orders", async (req, res) => {
  try {
    const { symbol } = req.query as { symbol?: string };
    const params: Record<string, string> = { status: "active" };
    if (symbol) params.symbol = symbol;
    const data = await kucoinGet("/api/v1/orders", params, true);
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post("/order", async (req, res): Promise<void> => {
  try {
    const { symbol, side, type = "market", size, price, funds, clientOid } = req.body || {};
    if (!symbol || !side) {
      res.status(400).json({ error: "symbol, side required" });
      return;
    }
    const order: Record<string, any> = {
      clientOid: clientOid || `sm_${Date.now()}`,
      symbol,
      side,
      type,
    };
    if (size) order.size = String(size);
    if (price && type === "limit") order.price = String(price);
    if (funds && type === "market") order.funds = String(funds);
    const data = await kucoinPost("/api/v1/orders", order);
    res.json(data);
  } catch (err: any) {
    console.error("KuCoin order error:", err.message);
    res.status(500).json({ error: err.message });
  }
});

router.delete("/order/:orderId", async (req, res): Promise<void> => {
  try {
    const { orderId } = req.params;
    if (!orderId) {
      res.status(400).json({ error: "orderId required" });
      return;
    }
    const data = await kucoinDelete(`/api/v1/orders/${orderId}`);
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.get("/my-trades", async (req, res) => {
  try {
    const { symbol } = req.query as { symbol?: string };
    const params: Record<string, string> = {};
    if (symbol) params.symbol = symbol;
    const data = await kucoinGet("/api/v1/fills", params, true);
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
